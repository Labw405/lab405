echo "the best score" > score.txt
for i in {1..20000}
do
    if [ -f npfsm_$i.pdbqt ];then
        echo "npfsm_$i.pdbqt" >>score.txt
        /home/pingw/anaconda3/bin/vina --config 2bxh-1-wi-config.txt --ligand npfsm_$i.pdbqt --out /home/pingw/compounds/out_pdbqt/npfsm_out_$i.pdbqt --log /home/pingw/compounds/out_log/npfsm_$i
        cat /home/pingw/compounds/out_pdbqt/npfsm_out_$i.pdbqt|sed -n '2p' >>score.txt
    else
        echo "no such file of npfsm_$i.pdbqt" >>score.txt
    fi
    ((i=i+1))
done

