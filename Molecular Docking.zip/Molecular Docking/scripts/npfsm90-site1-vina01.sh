echo "The best score" > npfsm90-site1-score01.txt
awk '{print $1}' score0-1.txt
for i in `awk '{print $1}' score0-1.txt`
do
    /home/pingw/anaconda3/bin/vina --config 2bxh-1-wi-site1-config.txt --ligand /home/pingw/compounds/re-npfsm90/$i --out /home/pingw/compounds/npfsm90-site1-out/out_$i --log /home/pingw/compounds/out_log/npfsm90-site1/$i_log.txt
    cat /home/pingw/compounds/npfsm90-site1-out/out_$i|sed -n '2p' >> npfsm90-site1-score01.txt
    echo "$i" >>npfsm90-site1-score01.txt
done

