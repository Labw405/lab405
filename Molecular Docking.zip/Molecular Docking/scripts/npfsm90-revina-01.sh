echo "The best score" > re90-score01.txt
awk '{print $1}' score0-1.txt
for i in `awk '{print $1}' score0-1.txt`
do
    /home/pingw/anaconda3/bin/vina --config 2bxh-1-wi-config1.txt --ligand /home/pingw/compounds/re-npfsm90/$i --out /home/pingw/compounds/re-npfsm90-out/out_$i --log /home/pingw/compounds/out_log/re-npfsm90/$i_log.txt
    cat /home/pingw/compounds/re-npfsm90-out/out_$i|sed -n '2p' >> re90-score01.txt
    echo "$i" >>re90-score01.txt
done


