name=Candidate compound code to be simulated

/data/gromacs/gmx2019.6/bin/gmx editconf -f ${name}_complex.gro -o newbox.gro -c -bt cubic -d 1.0
/data/gromacs/gmx2019.6/bin/gmx solvate -cp newbox.gro -cs spc216.gro -p topol.top -o solv.gro

/data/gromacs/gmx2019.6/bin/gmx grompp -f em.mdp -c solv.gro -p topol.top -o ions.tpr -maxwarn 1

echo 15 |/data/gromacs/gmx2019.6/bin/gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral

/data/gromacs/gmx2019.6/bin/gmx grompp -f em_real.mdp -c solv_ions.gro -p topol.top -o em.tpr

/data/gromacs/gmx2019.6/bin/gmx mdrun -deffnm em

echo 10 0 |/data/gromacs/gmx2019.6/bin/gmx energy -f em.edr -o potential.xvg

echo 2 |/data/gromacs/gmx2019.6/bin/gmx genrestr -f ${name}.gro -o posre_MOL.itp -fc 1000 1000 1000

sed -i '/; Include water topology/i;Ligand position restraints\n#ifdef POSRES\n#include "posre_MOL.itp"\n#endif\n' topol.top

echo -e "1|13\nq\n"|/data/gromacs/gmx2019.6/bin/gmx make_ndx -f em.gro -o index.ndx

/data/gromacs/gmx2019.6/bin/gmx grompp -f nvt.mdp -c em.gro -p topol.top -o nvt.tpr -r em.gro -n index.ndx

/data/gromacs/gmx2019.6/bin/gmx mdrun -deffnm nvt

echo 15 0 |/data/gromacs/gmx2019.6/bin/gmx energy -f nvt.edr -o temperature.xvg

/data/gromacs/gmx2019.6/bin/gmx grompp -f npt.mdp -c nvt.gro -t nvt.cpt -p topol.top -o npt.tpr -r nvt.gro -n index.ndx

/data/gromacs/gmx2019.6/bin/gmx mdrun -deffnm npt

echo 16 0 |/data/gromacs/gmx2019.6/bin/gmx energy -f npt.edr -o pressure.xvg
echo 22 0 |/data/gromacs/gmx2019.6/bin/gmx energy -f npt.edr -o density.xvg

/data/gromacs/gmx2019.6/bin/gmx grompp -f md.mdp -c npt.gro -t npt.cpt -p topol.top -o md_0_200.tpr -r npt.gro -n index.ndx

/data/gromacs/gmx2019.6/bin/gmx mdrun -deffnm md_0_200

echo -e "13 & ! a H*\nname23 MOL_heavy\n4|23\nr 411|r 410|r 489|r 391|r 430|r 414\nq\n"|/data/gromacs/gmx2019.6/bin/gmx make_ndx -f em.gro -n index.ndx

echo 22 0 |/data/gromacs/gmx2019.6/bin/gmx trjconv -s md_0_200.tpr -f md_0_200.xtc -n index.ndx -o md_0_200_pbccluster.xtc -pbc cluster

echo 4 4 |/data/gromacs/gmx2019.6/bin/gmx rms -s md_0_200.tpr -f md_0_200_pbccluster.xtc -o rmsd_pro.xvg -tu ns

echo 1 |/data/gromacs/gmx2019.6/bin/gmx gyrate -s md_0_200.tpr -f md_0_200_pbccluster.xtc -o gyrate.xvg

echo 1 |/data/gromacs/gmx2019.6/bin/gmx rmsf -s md_0_200.tpr -f md_0_200_pbccluster.xtc -o rmsf_temp.xvg -ox rmsf_avg.pdb -res -oq rmsf_bfac.pdb

echo 1 13 |/data/gromacs/gmx2019.6/bin/gmx hbond -s md_0_200.tpr -f md_0_200_pbccluster.xtc -n index.ndx -num hbond_num.xvg -dt 100 -life hbond_life.xvg

echo 13 25 |/data/gromacs/gmx2019.6/bin/gmx hbond -s md_0_200.tpr -f md_0_200_pbccluster.xtc -n index.ndx -num hbond_num_aa.xvg -dt 100 -life hbond_life_aa.xvg

